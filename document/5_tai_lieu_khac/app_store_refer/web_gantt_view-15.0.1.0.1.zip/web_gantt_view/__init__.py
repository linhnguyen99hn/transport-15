# -*- coding: utf-8 -*-

#Avoid loading schema as it causes issue on MRP (gantt view is there)
#from . import view_validation

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: