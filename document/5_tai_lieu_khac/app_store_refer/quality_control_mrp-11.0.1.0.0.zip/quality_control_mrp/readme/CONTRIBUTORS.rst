* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Simone Rubino <simone.rubino@agilebg.com>
* Ignacio José Alés López <ignacio.ales@guadaltech.es>
