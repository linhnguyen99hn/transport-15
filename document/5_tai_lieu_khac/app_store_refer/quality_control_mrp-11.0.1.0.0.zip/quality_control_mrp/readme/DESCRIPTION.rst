This module defines a trigger that creates quality control inspections when a
production order is finished.

It also adds the shortcuts related to these inspections on production orders.
