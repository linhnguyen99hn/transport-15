* Put trigger in all languages.
